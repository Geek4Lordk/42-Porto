/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_prime.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jopessoa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/09 17:30:22 by jopessoa          #+#    #+#             */
/*   Updated: 2022/10/09 18:24:23 by jopessoa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_prime(int nb)
{
	int	i;
	int	l;

	l = 0;
	i = 2;
	while (i < nb)
	{
		if (nb % i == 0)
		{
			l++;
		}
		i++;
	}
	if (l == 0 && (nb != 0 && nb != 1))
	{
		return (1);
	}
	else
	{
		return (0);
	}
}

#include <stdio.h>
int main(void)
{
	printf("%i", ft_is_prime(2));
	printf("%i", ft_is_prime(0));
	printf("%i", ft_is_prime(1));
	printf("%i", ft_is_prime(71));
	printf("%i", ft_is_prime(73));
	printf("%i", ft_is_prime(50));
	printf("%i", ft_is_prime(60));
	printf("%i", ft_is_prime(70));
	printf("%i", ft_is_prime(2147483647));

}
