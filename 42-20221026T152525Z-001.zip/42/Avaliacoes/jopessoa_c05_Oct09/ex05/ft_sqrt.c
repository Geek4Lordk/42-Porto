/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jopessoa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/09 15:38:04 by jopessoa          #+#    #+#             */
/*   Updated: 2022/10/09 17:12:41 by jopessoa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_sqrt(int nb)
{
	long	i;

	i = 1;
	if (nb <= 0)
	{
		return (0);
	}
	while (i * i < nb)
	{
		i++;
	}
	if (i * i == nb)
	{
		return (i);
	}
	else
	{
		return (0);
	}
}

#include <stdio.h>
int	main(void)
{
	printf("%i\n", ft_sqrt(16));
	printf("%i\n", ft_sqrt(27));
	printf("%i\n", ft_sqrt(-3));
	printf("%i\n", ft_sqrt(3999));
	printf("%i\n", ft_sqrt(100000000));
	printf("%i\n", ft_sqrt(0));
	printf("%i\n", ft_sqrt(81));
	printf("%i\n", ft_sqrt(9));
}
