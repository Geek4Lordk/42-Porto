/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jopessoa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/09 18:25:06 by jopessoa          #+#    #+#             */
/*   Updated: 2022/10/09 19:09:40 by jopessoa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_prime(int nb)
{
	int	i;
	int	l;

	l = 0;
	i = 2;
	while (i < nb)
	{
		if (nb % i == 0)
		{
			l++;
		}
		i++;
	}
	if (l == 0 && (nb != 0 && nb != 1))
	{
		return (1);
	}
	else
	{
		return (0);
	}
}

int	ft_find_next_prime(int nb)
{
	while (nb >= 2)
	{
		if (ft_is_prime(nb) == 1)
		{
			return (nb);
		}
	nb++;
	}
	return (2);
}

#include <stdio.h>
int main(void)
{

	printf("%i\n", ft_find_next_prime(2147483647));
}
