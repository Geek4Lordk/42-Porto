/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bbento-e <bbento-e@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/03 15:02:11 by bbento-e          #+#    #+#             */
/*   Updated: 2022/10/06 13:10:30 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n && src[i] != '\0')
	{
		dest[i] = src[i];
		++i;
	}
	if (i < n)
	{
		while (i < n)
		{
			dest[i] = '\0';
			++i;
		}
	}
	else
		dest[i] = '\0';
	return (dest);
}

#include <stdio.h>
#include <string.h>

int main(void)
{
	char a[] = "hello";
	char b[] = "a";

	ft_strncpy(b, a, 3);
	printf("%s\n", b);
	return 0;
}
