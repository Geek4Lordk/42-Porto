/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bbento-e <bbento-e@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/05 16:29:49 by ber               #+#    #+#             */
/*   Updated: 2022/10/06 10:09:30 by bbento-e         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	aux;

	i = 0;
	aux = 0;
	while (src[aux] != '\0')
		aux++;
	if (size < aux)
		return (size);
	while (src[i] != '\0' && i < (size - 1))
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (aux);
}
/* #include <stdio.h>
#include <string.h>
int main(void)
{
	char src[] = "Hello world";
	char dest[] = "";
	printf("Return: %i\n", ft_strlcpy(dest, src, 10));
	printf("Dest value: %s", dest);
	return 0;
} */
