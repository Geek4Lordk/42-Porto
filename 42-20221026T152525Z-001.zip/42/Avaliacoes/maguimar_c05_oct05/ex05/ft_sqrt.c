/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: maguimar <maguimar@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 18:35:46 by maguimar          #+#    #+#             */
/*   Updated: 2022/10/05 11:35:36 by maguimar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_sqrt(int nb)
{
	unsigned int	result;
	int				n;

	n = 1;
	result = 0;
	if ((unsigned int)nb == 0)
	{
		return (0);
	}
	while (result < (unsigned int)nb)
	{
		n++;
		result = n * n;
	}
	if (result == (unsigned int)nb)
		return (n);
	else
		return (0);
}
