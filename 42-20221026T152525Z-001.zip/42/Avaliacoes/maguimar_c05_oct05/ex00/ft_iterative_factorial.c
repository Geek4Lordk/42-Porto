/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: maguimar <maguimar@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/01 12:49:43 by maguimar          #+#    #+#             */
/*   Updated: 2022/10/04 09:25:11 by maguimar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	factorial;
	int	i;

	i = 0;
	factorial = 1;
	if (nb < 0)
	{
		return (0);
	}
	while (i < nb)
	{
		i++;
		factorial *= i;
	}
	return (factorial);
}
