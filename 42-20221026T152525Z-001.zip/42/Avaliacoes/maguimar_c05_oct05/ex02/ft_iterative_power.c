/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: maguimar <maguimar@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 13:52:33 by maguimar          #+#    #+#             */
/*   Updated: 2022/10/04 09:26:17 by maguimar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	res;
	int	i;

	i = 1;
	res = 1;
	while (i <= power)
	{
		res *= nb;
		i++;
	}
	if (power < 0)
	{
		return (0);
	}
	return (res);
}
