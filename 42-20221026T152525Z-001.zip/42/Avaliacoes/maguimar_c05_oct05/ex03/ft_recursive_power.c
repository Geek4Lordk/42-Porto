/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: maguimar <maguimar@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 15:51:10 by maguimar          #+#    #+#             */
/*   Updated: 2022/10/04 09:25:45 by maguimar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_power(int nb, int power)
{
	int	res;

	res = 1;
	if (power >= 1)
	{
		res *= nb * ft_recursive_power(nb, power - 1);
	}
	else if (nb < 0)
	{
		return (0);
	}
	return (res);
}
