/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acanelas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/03 16:53:41 by acanelas          #+#    #+#             */
/*   Updated: 2022/10/03 17:10:03 by acanelas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
//#include <stdio.h>

int	ft_str_is_numeric(char *str)
{
	int	a;

	a = 0;
	if (str[a] == '\0')
		return (1);
	while (str[a] != '\0')
	{
		if (str[a] >= '0' && str[a] <= '9')
		{
			a++;
		}
		else
			return (0);
	}
	return (1);
}
/*
int	main(int argc, char **argv)
{
	if (argc > 0)
	printf("%d\n", ft_str_is_numeric(argv[3]));
	printf("%d", ft_str_is_numeric(argv[2]));
	return (0);
}
*/
