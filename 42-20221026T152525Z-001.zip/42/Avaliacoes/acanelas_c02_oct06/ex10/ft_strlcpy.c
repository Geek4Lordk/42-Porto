/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acanelas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/03 18:14:02 by acanelas          #+#    #+#             */
/*   Updated: 2022/10/03 18:28:24 by acanelas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
//#include <unistd.h>

int	ft_strlen(char *str)
{
	int	a;

	a = 0;
	while (str[a] != '\0')
		a++;
	return (a);
}

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	c;
	unsigned int	b;

	b = ft_strlen(src);
	c = 0;
	if (size != 0)
	{
		while (src [c] != '\0' && c < size - 1)
		{
			dest[c] = src[c];
			c++;
		}
		dest[c] = '\0';
	}
	return (b);
}
/*
int	main(int argc, char **argv)
{
	if (argc > 0)
	printf(" |dest: %s   |src %s\n", argv[1], argv[2]);
	printf("number is: %d", ft_strlcpy(argv[1], argv[2], 60));
	printf(" |dest: %s   |", argv[1]);
}
*/
