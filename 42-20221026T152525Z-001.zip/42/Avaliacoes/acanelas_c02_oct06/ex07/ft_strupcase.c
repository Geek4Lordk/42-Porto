/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acanelas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/03 17:43:12 by acanelas          #+#    #+#             */
/*   Updated: 2022/10/03 17:53:26 by acanelas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
//#include <stdio.h>

char	*ft_strupcase(char *str)
{
	int	a;

	a = 0;
	while (str[a] != '\0')
	{
		if (str[a] >= 'a' && str[a] <= 'z')
		{	
			str[a] = str[a] - 32;
		}
		a++;
	}
	return (str);
}
/*
int	main(int argc, char **argv)
{
	if (argc >0)
	printf("%s", ft_strupcase(argv[3]));
	return (0);
}
*/
