/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acanelas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 16:48:06 by acanelas          #+#    #+#             */
/*   Updated: 2022/10/06 17:24:59 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <string.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	b;

	b = 0;
	while (src[b] != '\0' && n > b)
	{
		dest[b] = src[b];
		b++;
	}
	dest[b] = '\0';
	return (dest);
}

int	main(void)
{
	char src [] = "fuck pointers";
	char dest [] = "love pointers";
	unsigned int c;
	c = 3;
	printf("%s\n", dest);
	printf("%s\n", strncpy(dest, src, c));
	printf("%s\n", dest);
}
