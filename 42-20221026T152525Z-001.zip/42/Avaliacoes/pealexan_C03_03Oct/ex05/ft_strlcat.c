/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pealexan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 12:21:40 by pealexan          #+#    #+#             */
/*   Updated: 2022/10/03 16:10:16 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	a;
	unsigned int	b;
	unsigned int	destlen;
	unsigned int	srclen;

	a = 0;
	b = 0;
	while (dest[b] != '\0')
	{
		b++;
	}
	destlen = b;
	srclen = ft_strlen(src);
	if (size == 0 || size <= destlen)
		return (srclen + size);
	while (src [a] != '\0' && a < size - destlen - 1)
	{
		dest[b] = src[a];
		a++;
		b++;
	}
	dest[b] = '\0';
	return (destlen + srclen);
}

int	main(int argc, char **argv)
{
	int	size;

	size = 20;
	(void)argc;
	printf("%i \n", ft_strlcat(argv[2], argv[1], size));
	printf("%s \n", argv[2]);
}
