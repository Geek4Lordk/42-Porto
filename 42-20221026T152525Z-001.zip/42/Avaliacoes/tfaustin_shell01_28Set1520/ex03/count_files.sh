#!/bin/bash
find . | wc -l
