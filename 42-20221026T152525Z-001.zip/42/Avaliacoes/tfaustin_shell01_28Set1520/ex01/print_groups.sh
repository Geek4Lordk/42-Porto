#!/bin/bash
id -Gn $FT_USER | tr -s ' ' ',' | tr -d '\n'
