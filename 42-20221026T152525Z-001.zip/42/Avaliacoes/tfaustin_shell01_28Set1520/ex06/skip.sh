#!/bin/sh
ls -l | gawk "NR % 2 != 0"
