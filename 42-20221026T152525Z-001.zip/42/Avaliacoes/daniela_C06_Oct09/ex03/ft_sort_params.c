/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dreis-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/09 19:08:27 by dreis-ma          #+#    #+#             */
/*   Updated: 2022/10/09 19:11:49 by dreis-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_swap(char **a, char **b)
{
	char	*swap;

	swap = *a;
	*a = *b;
	*b = swap;
}

void	ft_putchar(char **b, int a, int i)
{
	int	j;

	while (i < a)
	{
		j = 0;
		while (b[i][j])
			j++;
		write(1, b[i], j);
		write(1, "\n", 1);
		i++;
	}
}

int	main(int argc, char **argv)
{
	int	i;
	int	j;

	i = 1;
	if (argc < 2)
		return (0);
	while (i < argc - 1)
	{
		j = 0;
		if (argv[i][j] == argv[i + 1][j])
		{
			while ((argv[i][j] || argv[i + 1][j])
			&& (argv[i][j] == argv[i + 1][j]))
				j++;
		}
		if (argv[i][j] > argv[i + 1][j])
		{
			ft_swap(&argv[i], &argv[i + 1]);
			i = 0;
		}
		i++;
	}
	ft_putchar(argv, argc, 1);
}
