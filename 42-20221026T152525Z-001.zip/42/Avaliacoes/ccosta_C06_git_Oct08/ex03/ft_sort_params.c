/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccosta-c <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/08 16:48:08 by ccosta-c          #+#    #+#             */
/*   Updated: 2022/10/08 19:27:39 by ccosta-c         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	put_str(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}

void	swap(char **a, char **b)
{
	char	*temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

int	str_cmp(char *str, char *str2)
{
	int	i;

	i = 0;
	while (str[i] != '\0' && str2[i] != '\0')
	{
		if (str[i] == str2[i])
		{
			i++;
		}
		else
		{
			return (str[i] - str2[i]);
		}
	}
	return (0);
}

int	main(int argc, char **argv)
{
	int	i;
	int	x;

	i = 1;
	while (i < argc - 1)
	{
		x = 1;
		while (x < argc - 1)
		{
			if (str_cmp(argv[x], argv[x + 1]) > 0)
			{	
				swap(&argv[x], &argv[x + 1]);
			}	
			x++;
		}
		i++;
	}
	i = 1;
	while (i < argc)
	{
		put_str(argv[i]);
		write(1, "\n", 1);
		i++;
	}	
}
