ifconfig -a
