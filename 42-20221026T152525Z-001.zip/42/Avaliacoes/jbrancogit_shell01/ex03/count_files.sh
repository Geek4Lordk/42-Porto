ls * | wc -l
