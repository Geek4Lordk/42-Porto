ls -l | sed -n 'n;p'
