echo $FT_NBR1 + $FT_NBR2
