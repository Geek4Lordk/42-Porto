sed -e '/^;/d'
