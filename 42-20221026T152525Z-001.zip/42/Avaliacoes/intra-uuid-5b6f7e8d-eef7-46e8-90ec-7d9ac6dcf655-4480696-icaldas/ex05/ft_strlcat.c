/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: icaldas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 17:32:44 by icaldas           #+#    #+#             */
/*   Updated: 2022/10/11 14:55:05 by icaldas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_len(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	j;
	unsigned int	lens;
	unsigned int	lend;

	j = 0;
	i = 0;
	while (dest[j] != '\0')
	{
		j++;
	}
	lend = j;
	lens = ft_len(src);
	if (size == 0 || size <= lend)
		return (lens + size);
	while (src[i] != '\0' && i < size - lend - 1)
	{
		dest[j] = src[i];
		i++;
		j++;
	}
	dest[j] = '\0';
	return (lend + lens);
}

#include <stdio.h>
#include <bsd/string.h>
int main(void)
{
	char src[]="ala";
	char dest[]="simokok";
	char src1[]="ala";
	char dest1[]="simokok";
	int size = 9;
	printf("%d\n",ft_strlcat(dest,src,size));
	printf("%s\n", dest);
	printf("%zu\n", strlcat(dest1, src1, size));
	printf("%s", dest1);
}

