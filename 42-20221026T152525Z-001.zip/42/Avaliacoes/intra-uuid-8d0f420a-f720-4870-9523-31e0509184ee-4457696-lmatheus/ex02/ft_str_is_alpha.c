/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lmatheus <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/11 01:21:54 by lmatheus          #+#    #+#             */
/*   Updated: 2022/10/11 01:41:27 by lmatheus         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	if (str[i] == '\0')
	{
		return (1);
	}
	while (str[i] != '\0')
	{
		if ((str[i] >= 'A' && str[i] <= 'Z')
			|| (str[i] >= 'a' && str[i] <= 'z'))
		{
			i++;
		}
		else
			return (0);
	}
	return (1);
}

int	main(void)
{
	char	seezero[] = "Abacate0quilom3tros";
	char	seeone[] = "AvocadoSuccess";
	char	seenothing[] = "";

	printf("%i\n", ft_str_is_alpha(seezero));
	printf("%i\n", ft_str_is_alpha(seeone));
	printf("%i", ft_str_is_alpha(seenothing));
}
