/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lmatheus <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/11 03:18:41 by lmatheus          #+#    #+#             */
/*   Updated: 2022/10/11 03:42:39 by lmatheus         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
		{
			str[i] += 32;
		}
		i++;
	}
	return (str);
}

char	*ft_strcapitalize(char *str)
{
	int	i;
	int	detect;

	i = 0;
	detect = 1;
	ft_strlowcase(str);
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
		{
			if (detect == 1)
			{
				str[i] -= 32;
				detect = 0;
			}
		}
		else if (str[i] >= '0' && str[i] <= '9')
		{
			detect = 0;
		}
		else
			detect = 1;
		i++;
	}
	return (str);
}

int	main(void)
{
	char	str[] = " SaLut, commENt tu vAs? 42mots QuarANte-deux; cinquANte+et+un";

	printf("%s", ft_strcapitalize(str));
}

