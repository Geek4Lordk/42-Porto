/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lmatheus <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/11 01:57:08 by lmatheus          #+#    #+#             */
/*   Updated: 2022/10/11 02:20:32 by lmatheus         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	if (str[i] == '\0')
	{
		return (1);
	}
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
		{
			i++;
		}
		else
			return (0);
	}
	return (1);
}

int	main(void)
{
	char    seezero[] = "Abacate0quilom3tros";
        char    seeone[] = "AAAAAAAAAAAAABACATE";
        char    seenothing[] = "";

        printf("%i\n", ft_str_is_uppercase(seezero));
        printf("%i\n", ft_str_is_uppercase(seeone));
        printf("%i", ft_str_is_uppercase(seenothing));
}

