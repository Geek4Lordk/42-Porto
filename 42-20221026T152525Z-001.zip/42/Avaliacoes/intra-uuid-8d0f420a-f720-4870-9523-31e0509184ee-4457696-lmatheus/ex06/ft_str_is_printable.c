/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lmatheus <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/11 02:34:35 by lmatheus          #+#    #+#             */
/*   Updated: 2022/10/11 02:46:10 by lmatheus         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	if (str[i] == '\0')
	{
		return (1);
	}
	while (str[i] != '\0')
	{
		if (str[i] >= 32 && str[i] <= 126)
		{
			i++;
		}
		else
			return (0);
	}
	return (1);
}

int     main(void)
{
	char    seezero[] = "Abacate0q\nuilom3tros";
	char    seeone[] = "AvocadoSuccess";
	char    seenothing[] = "";

	printf("%i\n", ft_str_is_printable(seezero));
	printf("%i\n", ft_str_is_printable(seeone));
	printf("%i", ft_str_is_printable(seenothing));
}

