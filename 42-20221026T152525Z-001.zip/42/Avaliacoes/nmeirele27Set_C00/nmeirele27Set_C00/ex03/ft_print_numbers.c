/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_numbers.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmeirele <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/23 16:00:55 by nmeirele          #+#    #+#             */
/*   Updated: 2022/09/27 12:26:14 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_numbers(void)
{
	char	digit;

	digit = '0' ;
	while (digit <= '9')
	{
		write(1, &digit, 1);
		digit++;
	}
}

int	main(void)
{
	ft_print_numbers();
	return (0);
}
