/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dde-lope <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 20:26:05 by dde-lope          #+#    #+#             */
/*   Updated: 2022/10/08 17:24:25 by dde-lope         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (!(str[i] >= '0' && str [i] <= '9'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
int	main(void)
{
	printf("empty %d\n", ft_str_is_numeric(""));
 	printf("space %d\n", ft_str_is_numeric(" "));
	printf("num %d\n", ft_str_is_numeric("12345"));
	printf("non num %d\n", ft_str_is_numeric("1a2b34"));
	printf("non num %d\n", ft_str_is_numeric(".123%4"));
}
