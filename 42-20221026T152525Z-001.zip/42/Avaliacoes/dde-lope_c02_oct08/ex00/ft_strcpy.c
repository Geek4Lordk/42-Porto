/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dde-lope <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 11:57:13 by dde-lope          #+#    #+#             */
/*   Updated: 2022/10/08 15:36:10 by dde-lope         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}
#include <stdio.h>
//The strcpy() function copies string2, including the ending null character, 
//to the location that is specified by string1. 

int	main(void)
{	
	char src[] = "abcdefg";
	char dest[] = "awdawdadawd";
	printf("dest: %s\n", dest);
        ft_strcpy(dest, src);
	printf("dest: %s\n", dest);
	return (0);
}
