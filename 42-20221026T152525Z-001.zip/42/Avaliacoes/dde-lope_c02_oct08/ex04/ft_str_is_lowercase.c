/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dde-lope <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 20:09:21 by dde-lope          #+#    #+#             */
/*   Updated: 2022/10/08 17:40:07 by dde-lope         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (!(str[i] >= 'a' && str[i] <= 'z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
int	main()
{
	printf("empty %d\n", ft_str_is_lowercase(""));
	printf("space %d\n", ft_str_is_lowercase(" "));
	printf("lower %d\n", ft_str_is_lowercase("bananas"));
        printf("non lower %d\n", ft_str_is_lowercase("BaNanAS"));
        printf("non lower %d\n", ft_str_is_lowercase("B4n3n$s"));
}
