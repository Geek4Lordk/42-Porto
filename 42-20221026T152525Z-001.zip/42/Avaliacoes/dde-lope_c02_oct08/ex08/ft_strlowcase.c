/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dde-lope <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 21:21:12 by dde-lope          #+#    #+#             */
/*   Updated: 2022/10/08 18:07:40 by dde-lope         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] >= 65 && str[i] <= 90)
		{
			str[i] += 32;
		}
		i++;
	}
	return (str);
}
int   main(void)
{
        char lower[] = "bananas";
    	char upper[] = "BANANAS";
    	char mix[] = "Ban$#S!";

    	printf("lower %s\n", ft_strlowcase(lower));
    	printf("upper %s\n", ft_strlowcase(upper));
    	printf("mix %s\n", ft_strlowcase(mix));
        return (0);
}
