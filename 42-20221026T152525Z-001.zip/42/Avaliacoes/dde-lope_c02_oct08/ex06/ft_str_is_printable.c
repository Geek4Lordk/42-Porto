/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dde-lope <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 20:48:51 by dde-lope          #+#    #+#             */
/*   Updated: 2022/10/08 17:49:07 by dde-lope         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (!(str[i] >= 32 && str[i] <= 126))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
int	main(void)
{
	printf("empty %d\n", ft_str_is_printable(""));
	printf("space %d\n", ft_str_is_printable(" "));
	printf("print %d\n", ft_str_is_printable("asas32423%%23"));
	printf("non print %d\n", ft_str_is_printable("\n\t"));
	return (0);
}
