/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dde-lope <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 21:03:41 by dde-lope          #+#    #+#             */
/*   Updated: 2022/10/08 18:02:09 by dde-lope         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
char	*ft_strupcase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] >= 97 && str[i] <= 122)
		{
			str[i] -= 32;
		}
	i++;
	}
	return (str);
}
int	main(void)
{	
	char lower[] = "bananas";
    	char upper[] = "BANANAS";
    	char mix[] = "Ban$#S!";

    	printf("lower %s\n", ft_strupcase(lower));
   	printf("upper %s\n", ft_strupcase(upper));
    	printf("mix %s\n", ft_strupcase(mix));
        return (0);
}
