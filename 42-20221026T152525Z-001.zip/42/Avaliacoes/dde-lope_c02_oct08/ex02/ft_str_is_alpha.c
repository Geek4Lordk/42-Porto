/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dde-lope <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 15:55:47 by dde-lope          #+#    #+#             */
/*   Updated: 2022/10/08 17:24:54 by dde-lope         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if ((str[i] >= 'A' && str [i] <= 'Z')
			|| (str [i] >= 'a' && str [i] <= 'z'))
			i++;
		else
			return (0);
	}
	return (1);
}
int	main(void)
{
	printf("empty %d\n", ft_str_is_alpha(""));
	printf("space %d\n", ft_str_is_alpha(" "));
	printf("alpha %d\n", ft_str_is_alpha("abcdefghijkl"));
	printf("non alpha %d\n", ft_str_is_alpha("abc1defghijkl"));
	printf("non alpha %d\n", ft_str_is_alpha("-_134556efghij67"));
	return(0);
}
