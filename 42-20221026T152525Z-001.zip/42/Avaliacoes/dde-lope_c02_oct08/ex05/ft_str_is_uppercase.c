/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dde-lope <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 20:30:35 by dde-lope          #+#    #+#             */
/*   Updated: 2022/10/08 17:42:52 by dde-lope         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (!(str[i] >= 'A' && str[i] <= 'Z' ))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
int	main(void)
{
	printf("empty %d\n", ft_str_is_uppercase(""));
        printf("space %d\n", ft_str_is_uppercase(" "));
        printf("lower %d\n", ft_str_is_uppercase("bananas"));
        printf("upper  %d\n", ft_str_is_uppercase("BANANAS"));
        printf("non upper %d\n", ft_str_is_uppercase("B4n3n$s"));	
	return (0);
}
