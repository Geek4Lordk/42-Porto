/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dde-lope <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/02 21:32:58 by dde-lope          #+#    #+#             */
/*   Updated: 2022/10/08 18:32:43 by dde-lope         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
		{
			str[i] += 32;
		}
		i++;
	}
	return (str);
}

char	*ft_strcapitalize(char *str)
{
	int	i;
	int	first_letter;

	i = 0;
	first_letter = 1;
	ft_strlowcase(str);
	while (str[i])
	{
		if (str[i] >= 'a' && str[i] <= 'z')
		{
			if (first_letter)
				str[i] -= 32;
			first_letter = 0;
		}
		else if (str[i] >= '0' && str[i] <= '9')
			first_letter = 0;
		else
			first_letter = 1;
		i++;
	}
	return (str);
}
int	main(void)
{
	char	string[] = "ba$An3S";
	char    spaces[] = " ba nA n3S";
	char	string1[] = "salut, comment tu vas ? 42mots quarante-deux;a";
	printf("%s\n", ft_strcapitalize(string));
	printf("%s\n", ft_strcapitalize(spaces));
	printf("%s\n", ft_strcapitalize(string1));
	return (0);
}
