#!/bin/sh
git ls-files --exclude-standard --others --ignore
