/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbatisti <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/27 09:51:57 by rbatisti          #+#    #+#             */
/*   Updated: 2022/09/28 17:35:16 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	if (str[0] == '\0')
	{
		return (1);
	}
	while (str[i] != '\0')
	{
		if ((str[i] > 64 && str[i] < 91) || (str[i] < 123 && str[i] > 96))
			i++;
		else
			return (0);
	}
	return (1);
}

int     main(void)
{
        char    src[10] = "";

        printf("%d", ft_str_is_alpha(src));
}

