/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbatisti <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/27 16:23:23 by rbatisti          #+#    #+#             */
/*   Updated: 2022/09/28 15:54:23 by rbatisti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] > 64 && str[i] < 91)
		{
			str[i] = str[i] + 32;
		}
		i++;
	}
	return (0);
}

char	*ft_strcapitalize(char *str)
{
	int	i;
	int	count;

	i = 0;
	ft_strlowcase(str);
	while (str[i] != '\0')
	{
		if (str[i] < 123 && str[i] > 96)
		{
			if (i == 0)
				str[i] = str[i] - 32;
			else if ((str[i - 1] > 64 && str[i - 1] < 91))
				count++;
			else if ((str[i - 1] < 123 && str[i - 1] > 96))
				count++;
			else if ((str[i - 1] > 48 && str[i - 1] < 57))
				count++;
			if (count == 0 && i != 0)
				str[i] = str[i] - 32;
		}
		i++;
		count = 0;
	}
	return (str);
}

int main()
{
	char	str[] = "salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un";
	
	printf("%s", ft_strcapitalize(str));
}
