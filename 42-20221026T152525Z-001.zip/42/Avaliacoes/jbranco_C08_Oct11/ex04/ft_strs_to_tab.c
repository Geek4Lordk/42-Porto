/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jbranco- <jbranco-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/08 16:37:12 by jbranco-          #+#    #+#             */
/*   Updated: 2022/10/09 11:22:04 by jbranco-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_stock_str.h"
#include "stdlib.h"

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

char	*ft_strdup(char *src)
{
	char	*new;
	int		i;
	int		size;

	i = 0;
	size = ft_strlen(src);
	new = (char *) malloc(size * sizeof(char) + 1);
	if (new != 0)
	{
		while (src[i] != '\0')
		{
			new[i] = src[i];
			i++;
		}	
	}
	else
	{
		return (0);
	}
	new[i] = '\0';
	return (new);
}

struct s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	int					i;
	struct s_stock_str	*val;

	i = 0;
	val = malloc(sizeof(t_stock_str) * ac + 1);
	while (av[i])
	{
		val[i].size = ft_strlen(av[i]);
		val[i].str = av[i];
		val[i].copy = ft_strdup(av[i]);
		i++;
	}
	val[i].copy = 0;
	val[i].size = 0;
	val[i].str = 0;
	return (val);
}
