#!/bin/bash
ifconfig | grep 'ether' | tr -s " " | cut -d " " -f 3
