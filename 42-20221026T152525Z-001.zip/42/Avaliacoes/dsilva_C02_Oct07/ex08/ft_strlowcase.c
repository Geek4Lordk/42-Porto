/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dsilva-m <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/06 11:14:05 by dsilva-m          #+#    #+#             */
/*   Updated: 2022/10/07 11:40:08 by dsilva-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if ((str[i] <= 'Z') && (str[i] >= 'A'))
		{
			str[i] += 32;
		}
		i++;
	}
	return (str);
}
/*
        int     main(int ac, char **av)
{
	printf("%s",ft_strupcase(av[1]));
        printf("\n");
        printf("%s",ft_strupcase(av[2]));
}
*/
