/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dsilva-m <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/03 13:28:45 by dsilva-m          #+#    #+#             */
/*   Updated: 2022/10/03 13:34:30 by dsilva-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'A' && str[i] <= 'Z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*
        int     main()
{
        char    s[] = {"F"};
        char    s2[] = {"f"};

        printf("%d", ft_str_is_uppercase(s));
        printf("\n");
        printf("%d", ft_str_is_uppercase(s2));
}
*/