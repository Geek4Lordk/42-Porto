/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dsilva-m <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/03 12:52:43 by dsilva-m          #+#    #+#             */
/*   Updated: 2022/10/03 13:25:08 by dsilva-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include<stdio.h>

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'a' && str[i] <= 'z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*
	int	main()
{	
	char	s[] = {"fFf"};
	char    s2[] = {"fuck"};
	
	printf("%d", ft_str_is_lowercase(s));
        printf("\n");
	printf("%d", ft_str_is_lowercase(s2));

}
*/