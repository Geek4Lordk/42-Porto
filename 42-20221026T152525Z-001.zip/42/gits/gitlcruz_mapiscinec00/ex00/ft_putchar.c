#include <unistd.h>

void ft_putchar(char c);

int main(void)
{
 return(0);
}
