#!/bin/sh
id --groups --name $FT_USER |tr -s ' ' ','|tr -d '\n'
