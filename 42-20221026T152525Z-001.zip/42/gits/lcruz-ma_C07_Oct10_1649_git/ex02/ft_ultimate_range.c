/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/12 11:55:14 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/10/12 14:24:19 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{	
	int	i;
	int	*res;

	i = 0;
	if (min >= max)
	{	
		return (-1);
	}
	res = (int *)malloc(sizeof(int) * (max - min));
	if (!res)
	{
		return (0);
	}
	while (i < max - min)
	{
		res[i] = min + i;
		i++;
	}
	*range = res;
	return (i);
}
/*
int	main(void)
{
	int	min;
	int	max;
	int	*range;
	int	i;

	min = 3;
	max = 9;
	i = 0;
	printf("%d\n", ft_ultimate_range(&range, min, max));
	while (i < max - min)
	{
		printf("%d", range[i]);
		i++;
	}
	return (0);
}*/
