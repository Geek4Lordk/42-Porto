/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/11 11:53:25 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/10/11 13:44:02 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
#include <stdlib.h>
//#include <string.h>

char	*ft_strdup(char *src)
{
	char	*dupl;
	int		n;

	n = 0;
	while (src[n])
		n++;
	dupl = (char *)malloc(sizeof(char) * n + 1);
	if (dupl == NULL)
		return (NULL);
	n = 0;
	while (src[n])
	{
		dupl[n] = src[n];
		n++;
	}
	dupl[n] = '\0';
	return (dupl);
}
/*
int	main(int argc, char **argv)
{
	argc = 3;
	printf("%p\n", &argv[2]);
	printf("%s\n", argv[2]);
	printf("%s\n", ft_strdup(argv[2]));
	printf("%p\n", ft_strdup(argv[2]));
	printf("\n");
	printf("%p\n", &argv[1]);
	printf("%s\n", argv[1]);
	printf("%s\n", strdup(argv[1]));
	printf("%p", strdup(argv[1]));
	return (0);
}*/
