/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/11 16:43:35 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/10/12 11:51:06 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*ptr;
	int	range;
	int	i;

	i = 0;
	range = max - min;
	if (min >= max)
		return (0);
	ptr = (int *)malloc(range * sizeof(int));
	while (i < range)
	{
		ptr[i] = min + i;
		i++;
	}
	return (ptr);
}
/*
int	main(void)
{
	int	min;
	int	max;
	int	i;

	min = 3;
	max = 11;
	i = 0;
	while (i < max - min)
	{
		printf("%d\n", ft_range(min, max)[i]);
		i++;
	}
	return (0);
}*/
