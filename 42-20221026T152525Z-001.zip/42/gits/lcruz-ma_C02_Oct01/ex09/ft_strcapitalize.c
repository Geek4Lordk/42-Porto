/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/03 17:37:13 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/10/04 11:37:57 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
#include <stdio.h>
*/
char	*ft_strcapitalize(char *str)
{
	int	a;

	a = 0;
	while (str[a] != '\0')
	{
		if (str[a] <= 'Z' && str[a] >= 'A')
			str[a] += 32;
		a++;
	}
	if (str[0] >= 'a' && str[0] <= 'z')
		str[0] -= 32;
	a = 1;
	while (str[a] != '\0')
	{
		if (str[a - 1] < 'a' || str[a - 1] > 'z')
			if (str[a -1] < 'A' || str[a - 1] > 'Z')
				if (str[a -1] < '0' || str[a - 1] > '9')
					if (str[a] >= 'a' && str[a] <= 'z')
						str[a] -= 32;
		a++;
	}
	return (str);
}
/*
int	main(int argc, char **str)
{
	argc = 2;
	printf("%s", ft_strcapitalize(str[1]));
	return (0);
}*/
