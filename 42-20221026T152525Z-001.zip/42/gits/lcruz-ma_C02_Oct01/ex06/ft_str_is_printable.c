/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/03 17:02:17 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/10/03 17:06:14 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
#include <stdio.h>
*/
int	ft_str_is_printable(char *str)
{
	int	a;
	int	b;

	a = 0;
	b = 0;
	while (str[a] != '\0')
	{
		a++;
	}
	while (str[b] <= 126 && str[b] >= 32)
	{
		b++;
	}
	if (a == b)
		return (1);
	else
		return (0);
}
/*
int	main(void)
{
	char c[] = "\0";
	printf("%d", ft_str_is_printable(c));
	return (0);
}*/
