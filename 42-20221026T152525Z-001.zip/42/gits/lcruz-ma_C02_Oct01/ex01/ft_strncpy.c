/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/03 12:43:59 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/10/06 13:14:20 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	a;

	a = 0;
	while (a < n && src[a] != '\0')
	{
		dest[a] = src[a];
		a++;
	}
	while (a < n)
	{
		dest[a] = '\0';
		a++;
	}
	return (dest);
}

int	main(void)
{
	char	src1[] = "Hello";
	char	dest1[] = "aaa";
	char	src2[] = "Hello";
	char	dest2[] = "aaa";

	printf("%s\n", strncpy(dest2, src2, 2));
	printf("%s\n", strncpy(dest1, src1, 2));
	return (0);
}
