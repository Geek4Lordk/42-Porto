/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/03 17:23:05 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/10/03 17:29:46 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
#include <stdio.h>
*/
char	*ft_strupcase(char *str)
{
	int	a;

	a = 0;
	while (str[a] != '\0')
	{
		if (str[a] <= 'z' && str[a] >= 'a')
			str[a] -= 32;
		a++;
	}
	return (str);
}
/*
int	main(int argc, char **str)
{
	argc = 2;
	printf("%s", ft_strupcase(str[1]));
	return (0);
}*/
