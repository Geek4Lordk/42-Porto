/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/03 14:12:41 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/10/03 15:14:02 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
#include <stdio.h>
*/
int	ft_str_is_alpha(char *str)
{
	int	i;
	int	a;

	i = 0;
	a = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	while ((str[a] >= 'A' && str[a] <= 'Z') || (str[a] >= 'a' && str[a] <= 'z'))
	{
		a++;
	}
	if (a == i)
		return (1);
	else
		return (0);
}
/*
int	main(void)
{
	char	str[] = "";
	printf("%d", ft_str_is_alpha(str));
	return (0);
}*/
