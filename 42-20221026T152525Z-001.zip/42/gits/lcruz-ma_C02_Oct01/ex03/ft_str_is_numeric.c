/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/03 16:26:02 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/10/03 16:36:44 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
#include <stdio.h>
*/
int	ft_str_is_numeric(char *str)
{
	int	a;
	int	b;

	a = 0;
	b = 0;
	while (str[a] != '\0')
	{
		a++;
	}
	while (str[b] <= '9' && str[b] >= '0')
	{
		b++;
	}
	if (a == b)
		return (1);
	else
		return (0);
}
/*
int	main(int argc, char **str)
{
	argc = 2;
	printf("%d", ft_str_is_numeric(str[1]));
	return (0);
}*/
